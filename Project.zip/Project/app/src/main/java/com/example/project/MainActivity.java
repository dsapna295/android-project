package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button hmbook;
    private Button hmtime;
    private Button hmcata;
    private Button hmoff;
    private Button hmstaff;
    private Button hmfeed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hmbook= findViewById(R.id.hmbook);
        hmtime= findViewById(R.id.hmtime);
        hmcata= findViewById(R.id.hmcata);
        hmoff= findViewById(R.id.hmoff);
        hmstaff= findViewById(R.id.hmstaff);
        hmfeed= findViewById(R.id.hmfeed);
        hmbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,Appointment.class);
                startActivity(intent);
            }
        });
        hmtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,timing.class);
                startActivity(intent);
            }
        });
        hmcata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,Catalog.class);
                startActivity(intent);
            }
        });
        hmoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,Offers.class);
                startActivity(intent);
            }
        });
        hmstaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,Staff.class);
                startActivity(intent);
            }
        });
        hmfeed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,Feedback.class);
                startActivity(intent);
            }
        });

    }
}