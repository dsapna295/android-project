package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class Appointment extends AppCompatActivity {

    EditText etDate;
    EditText chooseTime;
    DatePickerDialog.OnDateSetListener setListener;
    TimePickerDialog timePickerDialog;
    Calendar calendar1;
    int currentHour;
    int currentMinute;
    String amPm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        String[] type= new String[] {"Hair cut","Hair wash","Blow Drying","Hair straightening"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.drop_down_items,type);

        AutoCompleteTextView autoCompleteTextView= findViewById(R.id.filled_exposed);
        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(Appointment.this,autoCompleteTextView.getText().toString(),Toast.LENGTH_SHORT).show();
            }
        });


        etDate = findViewById(R.id.et_date);
        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(Appointment.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month = month+1;
                        String date = day+"/"+month+"/"+year;
                        etDate.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });


        chooseTime = findViewById(R.id.etChooseTime);
        chooseTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar1 = Calendar.getInstance();
                currentHour = calendar1.get(Calendar.HOUR_OF_DAY);
                currentMinute = calendar1.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(Appointment.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if(hourOfDay >=12){
                            amPm = "PM";
                        }else {
                            amPm = "AM";
                        }
                        chooseTime.setText(hourOfDay + ":" + minutes);
                    }
                },currentHour,currentMinute,false);

                timePickerDialog.show();
            }
        });
    }
}

